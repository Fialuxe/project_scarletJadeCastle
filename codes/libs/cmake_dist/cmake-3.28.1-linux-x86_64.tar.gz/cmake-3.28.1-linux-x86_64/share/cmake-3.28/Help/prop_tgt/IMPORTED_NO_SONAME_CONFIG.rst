IMPORTED_NO_SONAME_<CONFIG>
---------------------------

<CONFIG>-specific version of :prop_tgt:`IMPORTED_NO_SONAME` property.

Configuration names correspond to those provided by the project from
which the target is imported.
