VS_WINRT_REFERENCES
-------------------

Visual Studio project Windows Runtime Metadata references

Adds one or more semicolon-delimited WinRT references to a generated
Visual Studio project.  For example, "Windows;Windows.UI.Core".
