VS_DOTNET_DOCUMENTATION_FILE
----------------------------

.. versionadded:: 3.17

Visual Studio managed project .NET documentation output

Sets the target XML documentation file output.
