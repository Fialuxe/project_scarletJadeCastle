IMPORTED_LINK_INTERFACE_LANGUAGES_<CONFIG>
------------------------------------------

<CONFIG>-specific version of :prop_tgt:`IMPORTED_LINK_INTERFACE_LANGUAGES`.

Configuration names correspond to those provided by the project from
which the target is imported.  If set, this property completely
overrides the generic property for the named configuration.
